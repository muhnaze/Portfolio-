document.getElementById("year").textContent = new Date().getFullYear();

function showMessage() {
  alert("Welcome to Muhammad Nazir Ashana’s Portfolio!");
}
